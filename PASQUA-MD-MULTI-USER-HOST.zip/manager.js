
const { fork } = require('child_process')
const path = require('path')
const fs = require('fs')

const usersFile = path.join(__dirname, 'users.json')
if (!fs.existsSync(usersFile)) fs.writeFileSync(usersFile, JSON.stringify({ users: [] }, null, 2))

const children = {}

function loadUsers() {
  try { return JSON.parse(fs.readFileSync(usersFile)).users || [] } catch { return [] }
}
function saveUsers(users) {
  fs.writeFileSync(usersFile, JSON.stringify({ users }, null, 2))
}
function startUser(phone) {
  if (children[phone]) return
  const sessionPath = path.join(__dirname, 'sessions', phone)
  fs.mkdirSync(sessionPath, { recursive: true })
  const child = fork(path.join(__dirname, 'index.js'), [], { env: { ...process.env, SESSION_PATH: sessionPath } })
  children[phone] = child
  child.on('exit', () => delete children[phone])
}
function startAll() { loadUsers().forEach(startUser) }
function addUser(phone) {
  const users = loadUsers()
  if (!users.includes(phone)) { users.push(phone); saveUsers(users) }
  startUser(phone)
}
module.exports = { startAll, addUser }
