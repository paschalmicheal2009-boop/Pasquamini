
const TelegramBot = require('node-telegram-bot-api')
const fs = require('fs')
const path = require('path')
const manager = require('./manager')
const { default: makeWASocket, useMultiFileAuthState } = require('@whiskeysockets/baileys')

const TOKEN = "8544314302:AAEPaB3hq8Pd6EBxHeK8xcs2w1IeeTPaKqA"
const bot = new TelegramBot(TOKEN, { polling: true })

bot.onText(/\/start/, (msg) => {
  bot.sendMessage(msg.chat.id, `👋 PASQUA MD Multi-User Pairing\n\nSend:\n/pair 234xxxxxxxxx`)
})

bot.onText(/\/pair (.+)/, async (msg, match) => {
  const chatId = msg.chat.id
  const phone = match[1].replace(/\D/g, '')
  if (!phone.startsWith('234')) return bot.sendMessage(chatId, '❌ Use country code.')

  const sessionPath = path.join(__dirname, 'sessions', phone)
  fs.mkdirSync(sessionPath, { recursive: true })
  const { state, saveCreds } = await useMultiFileAuthState(sessionPath)
  const sock = makeWASocket({ auth: state, printQRInTerminal: false })
  sock.ev.on('creds.update', saveCreds)

  const code = await sock.requestPairingCode(phone)
  await bot.sendMessage(chatId, `🔐 Pairing Code\n\n📱 ${phone}\n🔢 ${code}`)

  sock.ev.on('connection.update', (u) => {
    if (u.connection === 'open') {
      manager.addUser(phone)
      try { sock.end() } catch {}
    }
  })
})
